<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/grav-admin/user/data/flex/indexes/accounts.yaml',
    'modified' => 1671204098,
    'data' => [
        'version' => '1.1',
        'timestamp' => 1671204098,
        'count' => 1,
        'index' => [
            'admin' => [
                'storage_key' => 'admin',
                'storage_timestamp' => 1671204097,
                'key' => 'admin',
                'email' => 'person@example.com'
            ]
        ]
    ]
];
