<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledJsonFile',
    'filename' => '/var/www/html/grav-admin/user/data/flex/indexes/pages.json',
    'modified' => 1671204098,
    'data' => [
        'version' => '1.5',
        'timestamp' => 1671204098,
        'count' => 3,
        'index' => [
            '' => [
                'key' => '',
                'storage_key' => '',
                'template' => NULL,
                'storage_timestamp' => 1616003172,
                'children' => [
                    '01.home' => 1616003172,
                    '02.typography' => 1616003172
                ],
                'checksum' => 'f3e5bce0feb638bb00357d72962e6b18'
            ],
            '01.home' => [
                'key' => 'home',
                'storage_key' => '01.home',
                'template' => 'default',
                'storage_timestamp' => 1616003172,
                'markdown' => [
                    '' => [
                        'default' => 1616003172
                    ]
                ],
                'checksum' => '8a88974e3fd2f9b339efa5e89a330641'
            ],
            '02.typography' => [
                'key' => 'typography',
                'storage_key' => '02.typography',
                'template' => 'default',
                'storage_timestamp' => 1616003172,
                'markdown' => [
                    '' => [
                        'default' => 1616003172
                    ]
                ],
                'checksum' => 'eaafd84ec6236b8c499850d00c15e737'
            ]
        ]
    ]
];
