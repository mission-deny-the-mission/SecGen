<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/grav-admin/user/config/media.yaml',
    'modified' => 1671203542,
    'data' => [
        
    ]
];
