<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/grav-admin/user/accounts/admin.yaml',
    'modified' => 1671204097,
    'data' => [
        'state' => 'enabled',
        'email' => 'person@example.com',
        'fullname' => 'John Doe',
        'title' => 'admin',
        'access' => [
            'admin' => [
                'login' => true,
                'super' => true
            ],
            'site' => [
                'login' => true
            ]
        ],
        'hashed_password' => '$2y$10$9O9H9IzrLq2LHaXEsLC0IuAyWDeRsmICMYd/Z7lM03HndDiF3CnEK'
    ]
];
