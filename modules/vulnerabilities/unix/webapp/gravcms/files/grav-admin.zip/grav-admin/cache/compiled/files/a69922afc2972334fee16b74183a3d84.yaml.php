<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/grav-admin/user/config/security.yaml',
    'modified' => 1671203541,
    'data' => [
        'salt' => 'tAWlRXyYx9C3Bk'
    ]
];
