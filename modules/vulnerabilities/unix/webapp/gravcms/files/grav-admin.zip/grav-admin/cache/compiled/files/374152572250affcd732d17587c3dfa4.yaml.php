<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/grav-admin/user/plugins/flex-objects/languages/en.yaml',
    'modified' => 1616003172,
    'data' => [
        'PLUGIN_FLEX_OBJECTS' => [
            'PLUGIN_NAME' => 'Flex Objects',
            'PLUGIN_DESCRIPTION' => 'Flex Objects plugin allows you to manage Flex Objects in Grav Admin.',
            'CREATED_SUCCESSFULLY' => 'Successfully created',
            'UPDATED_SUCCESSFULLY' => 'Successfully updated',
            'DELETED_SUCCESSFULLY' => 'Successfully deleted',
            'BUTTON_UP' => 'Go Up',
            'USE_BUILT_IN_CSS' => 'Use built in CSS',
            'EXTRA_ADMIN_TWIG_PATH' => 'Extra Admin Twig Path',
            'DIRECTORIES' => 'Directories',
            'LAYOUT_NOT_FOUND' => 'Object layout \'%s\' not found.',
            'CSV' => 'CSV'
        ]
    ]
];
