<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/grav-admin/user/config/versions.yaml',
    'modified' => 1671203541,
    'data' => [
        'core' => [
            'grav' => [
                'version' => '1.7.8',
                'schema' => '1.7.0_2020-11-20_1'
            ]
        ]
    ]
];
